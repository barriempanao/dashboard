import "../styles/globals.css";
import { useEffect, useState } from "react";
import { UserManager } from "oidc-client-ts";

const cognitoAuthConfig = {
  authority: "https://cognito-idp.us-east-1.amazonaws.com/us-east-1_b0tpHM55u",
  client_id: "4fbadbb2qqj15u0vf5dmauudbj",
  redirect_uri: "https://dashboard.total-remote-control.com/",
  response_type: "code",
  scope: "email openid profile",
};

const userManager = new UserManager(cognitoAuthConfig);

function MyApp({ Component, pageProps }) {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const handleAuthentication = async () => {
      const params = new URLSearchParams(window.location.search);
      
      // Si se detecta el parámetro "code", se procesa el callback
      if (params.has("code")) {
        try {
          const currentUser = await userManager.signinRedirectCallback();
          console.log("Usuario autenticado:", currentUser);
          setUser(currentUser);
        } catch (error) {
          console.error("Error al autenticar en callback:", error);
        } finally {
          setLoading(false);
        }
      } else {
        // No se detecta el parámetro, redirigir al hosted UI para autenticarse
        try {
          await userManager.signinRedirect();
        } catch (error) {
          console.error("Error al redirigir para autenticación:", error);
          setLoading(false); // Por si ocurre algún error, para evitar quedar en "Cargando..."
        }
      }
    };

    handleAuthentication();
  }, []);

  if (loading) {
    return <div style={loadingStyle}>Cargando...</div>;
  }

  return <Component {...pageProps} user={user} />;
}

const loadingStyle = {
  display: "flex",
  justifyContent: "center",
  alignItems: "center",
  height: "100vh",
  fontSize: "20px",
  fontWeight: "bold",
};

export default MyApp;
