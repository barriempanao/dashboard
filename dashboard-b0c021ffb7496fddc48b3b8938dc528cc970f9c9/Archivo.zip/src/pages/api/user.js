import mysql from 'mysql2/promise';

// Configuración de la conexión a la base de datos MySQL en RDS
const dbConfig = {
  host: 'total-remote-sql-database.ccj4go2eagl0.us-east-1.rds.amazonaws.com',
  user: 'admin', // Asegúrate de usar el usuario correcto
  password: 'Meekeat1073!!', // Usa una variable de entorno para seguridad
  database: 'total_remote_control',
};

export default async function handler(req, res) {
  if (req.method === 'GET') {
    return getUser(req, res);
  } else if (req.method === 'PUT') {
    return updateUser(req, res);
  } else {
    res.setHeader('Allow', ['GET', 'PUT']);
    return res.status(405).json({ error: `Method ${req.method} Not Allowed` });
  }
}

// Obtener datos del usuario autenticado
async function getUser(req, res) {
  try {
    const email = req.headers['x-user-email']; // Obtener email del usuario desde Cognito
    if (!email) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const connection = await mysql.createConnection(dbConfig);
    const [rows] = await connection.execute(
      'SELECT first_name, last_name, email, address, country, tax_identifier, phone FROM users WHERE email = ?',
      [email]
    );
    connection.end();

    if (rows.length === 0) {
      return res.status(404).json({ error: 'User not found' });
    }

    return res.status(200).json(rows[0]);
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
}

// Actualizar datos del usuario autenticado
async function updateUser(req, res) {
  try {
    const email = req.headers['x-user-email']; // Obtener email del usuario desde Cognito
    if (!email) {
      return res.status(401).json({ error: 'Unauthorized' });
    }

    const { first_name, last_name, address, country, tax_identifier, phone } = req.body;
    const connection = await mysql.createConnection(dbConfig);
    await connection.execute(
      'UPDATE users SET first_name = ?, last_name = ?, address = ?, country = ?, tax_identifier = ?, phone = ? WHERE email = ?',
      [first_name, last_name, address, country, tax_identifier, phone, email]
    );
    connection.end();

    return res.status(200).json({ message: 'User updated successfully' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Internal Server Error' });
  }
}
