// pages/dashboard/devices.js
import Layout from '../../components/Layout';

export default function Devices() {
  return (
    <Layout>
      <h1>Authorized Devices</h1>
      <p>Aquí se mostrarán las máquinas autorizadas. Podrás eliminar las asociadas.</p>
      {/* Aquí agregarás componentes para listar y eliminar dispositivos */}
    </Layout>
  );
}
