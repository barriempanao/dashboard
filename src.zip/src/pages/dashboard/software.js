// pages/dashboard/software.js
import Layout from '../../components/Layout';

export default function Software() {
  return (
    <Layout>
      <h1>Software</h1>
      <p>Aquí se mostrarán iconos que permitirán descargar los instaladores y enlazar a la app store para iPad.</p>
      {/* Aquí agregarás enlaces o botones para iniciar las descargas */}
    </Layout>
  );
}
