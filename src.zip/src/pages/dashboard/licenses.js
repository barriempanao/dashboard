// pages/dashboard/licenses.js
import Layout from '../../components/Layout';

export default function Licenses() {
  return (
    <Layout>
      <h1>Licenses</h1>
      <p>Aquí se mostrarán todas las licencias asociadas al usuario, con todos los detalles.</p>
      {/* Aquí agregarás componentes para listar y ver detalles de las licencias */}
    </Layout>
  );
}
