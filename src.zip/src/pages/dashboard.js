export default function Dashboard() {
  return <div>Bienvenido al Dashboard</div>;
}
