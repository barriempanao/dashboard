import Layout from "../components/Layout";

export default function Home() {
  return (
    <Layout>
      <div>
        <h1>Bienvenido a la aplicación</h1>
        <p>Este es el inicio de tu dashboard.</p>
      </div>
    </Layout>
  );
}
